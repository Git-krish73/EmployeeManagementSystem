Employee Management System SQLite Database

Files:
- employees.db: SQLite database containing the employees table and five sample records.

Table columns:
- id (INTEGER PRIMARY KEY AUTOINCREMENT)
- name (TEXT)
- employee_id (TEXT UNIQUE)
- department (TEXT)
- designation (TEXT)
- salary (REAL)
- contact (TEXT)

Open employees.db using your SQLite application.
Important: Your Flask app must connect to this same database file for website changes to appear here.
